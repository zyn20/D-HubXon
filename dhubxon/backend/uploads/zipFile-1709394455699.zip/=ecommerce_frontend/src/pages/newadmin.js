import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const navigate = useNavigate(); // Use useNavigate hook

  useEffect(() => {
    fetch('http://127.0.0.1:5000/freelancer/products')
      .then(response => response.json())
      .then(data => setCourses(data))
      .catch(error => console.error('Error fetching courses:', error));
  }, []);

  const constructImageUrl = (image) => {
    return `http://127.0.0.1:5000${image.startsWith('/uploads') ? image : '/uploads/' + image}`;
  };

  const deleteCourse = (id) => {
    const isConfirmed = window.confirm('Are you sure you want to delete this course?');
    if (isConfirmed) {
      fetch(`http://127.0.0.1:5000/freelancer/courses/${id}`, { method: 'DELETE' })
        .then(response => {
          if (response.ok) {
            setCourses(courses.filter(course => course._id !== id));
          } else {
            alert('Error deleting course');
          }
        })
        .catch(error => console.error('Error deleting course:', error));
    }
  };

  // Function to navigate to the update form with the course ID
  const updateCourse = (id) => {
    navigate(`/update-course/${id}`); // Navigate to the update form
  };
  const addCourse = () => {
    navigate(`/products`); // Navigate to the update form
  };

  return (
       <>
       <nav class="bg-white shadow dark:bg-gray-800">
    <div class="container flex items-center justify-center p-6 mx-auto text-gray-600 capitalize dark:text-gray-300">
        <a href="#" class="text-gray-800 dark:text-gray-200 border-b-2 border-blue-500 mx-1.5 sm:mx-6">Products</a>    
    </div>
</nav>   
<div className='container mx-auto flex justify-center items-center mt-5'>
  <button onClick={() => addCourse()} className="bg-red-500 text-white p-2 rounded">Add new Product</button>
</div>

    <div className="container mt-6 mx-auto p-4">
      {courses.map(course => (
        <div key={course._id} className="flex items-center justify-between p-4 border-b-2">
          <img src={constructImageUrl(course.image)} alt={course.title} className="w-20 h-20 object-cover" />
          <div>{course.title}</div>
          <div>{course.size}</div>
          <button onClick={() => updateCourse(course._id)} className="bg-blue-500 text-white p-2 rounded">Update</button>
          <button onClick={() => deleteCourse(course._id)} className="bg-red-500 text-white p-2 rounded">Delete</button>
        </div>
      ))}
    </div>
    </>
  );
};

export default Courses;
