
import React, { useEffect, useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Swal from 'sweetalert2';
import { useNavigate, useParams } from 'react-router-dom';
import { FaImage } from 'react-icons/fa';

const ProductForm = () => {
    const navigate = useNavigate();
    const { id } = useParams(); // Use useParams to access the id parameter from the route

    const [formData, setFormData] = useState({
        category: '',
        description: '',
        image: '',
        price: '',
        rating: 0,
        count: 0,
        title: '',
        size: '',
    });

    const [imagePreview, setImagePreview] = useState(''); // Use for displaying the image

    const constructImageUrl = (image) => {
        return `http://127.0.0.1:5000${image.startsWith('/uploads') ? image : '/uploads/' + image}`;
    };

    useEffect(() => {
        const fetchProductDetails = async () => {
            try {
                const response = await fetch(`http://127.0.0.1:5000/freelancer/courses/${id}`);
                if (!response.ok) throw new Error('Product fetch failed');
                const data = await response.json();
                setFormData({
                    ...data,
                    rating: data.rating.rate, // Adjust according to your backend structure
                    count: data.rating.count,
                });
                // Set the image preview URL using the constructed image URL
                setImagePreview(constructImageUrl(data.image));
            } catch (error) {
                console.error('Error fetching product details:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to load product details. Please try again.',
                });
            }
        };

        fetchProductDetails();
    }, [id]);

    const onImageDrop = useCallback((acceptedFiles) => {
        const file = acceptedFiles[0];
        if (file && (file.type === 'image/png' || file.type === 'image/jpeg')) {
            // Set the file for uploading
            setFormData({ ...formData, image: file });
            // Update the preview
            setImagePreview(URL.createObjectURL(file));
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Only PNG or JPG files are accepted.',
            });
        }
    }, [formData]);

    const { getRootProps, getInputProps } = useDropzone({
        onDrop: onImageDrop,
        accept: 'image/png, image/jpeg',
        multiple: false,
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name === 'rating' || name === 'count') {
            setFormData({ ...formData, [name]: Number(value) });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior
    
        // Validate form data (example validation, add more as needed)
        if (!formData.category || !formData.description || !formData.price || !formData.title || !formData.size) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Please make sure all fields are filled out.',
            });
            return;
        }
    
        // Create FormData object to handle file upload
        const uploadFormData = new FormData();
        Object.keys(formData).forEach(key => {
            if (key === 'image' && formData.image instanceof File) {
                // Append file object for image
                uploadFormData.append('image', formData.image);
            } else if (key !== 'image') {
                // Append other data as strings
                uploadFormData.append(key, formData[key]);
            }
        });
    
        // Append rating and count separately if needed
        uploadFormData.append('rating[rate]', formData.rating.toString());
        uploadFormData.append('rating[count]', formData.count.toString());
    
        try {
            // Make PUT request to update product details
            const response = await fetch(`http://127.0.0.1:5000/freelancer/courses/${id}`, {
                method: 'PUT',
                body: uploadFormData, // Pass FormData to the request body
                // Don't set 'Content-Type' header so the browser can set it with the boundary
            });
    
            if (response.ok) {
                // If the request was successful, inform the user
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Product updated successfully!',
                }).then(() => navigate('/')); // Redirect or update UI as needed
            } else {
                // Handle server errors or unsuccessful update
                const error = await response.json(); // Assuming the server responds with JSON
                Swal.fire({
                    icon: 'error',
                    title: 'Update Failed',
                    text: error.message || 'There was a problem updating the product. Please try again.',
                });
            }
        } catch (error) {
            // Handle network errors
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Network Error',
                text: 'An error occurred while trying to update the product. Please check your connection and try again.',
            });
        }
    };
    

    return (
        <>
        <nav class="bg-white shadow dark:bg-gray-800">
        <div class="container flex items-center justify-center p-6 mx-auto text-gray-600 capitalize dark:text-gray-300">
            <a href="#" class="text-gray-800 dark:text-gray-200 border-b-2 border-blue-500 mx-1.5 sm:mx-6">Products</a>    
        </div>
    </nav>  
            <div className="max-w-md mx-auto mt-10 bg-white p-8 border border-gray-300 rounded-lg shadow-lg">
                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Rest of the form fields remain unchanged */}
                    <div className="mb-4">
                        <label htmlFor="category" className="block mb-2 text-sm font-semibold text-gray-700">Category</label>
                        <select name="category" value={formData.category} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md">
                            <option value="">Select a category</option>
                            {/* List of options */}
                            <option value="Graphics Design">Graphics Design</option>
                            <option value="Web Development">Web Development</option>
                            <option value="Digital Marketing">Digital Marketing</option>
                            <option value="AI">AI</option>
                            <option value="Writing">Writing</option>
                            <option value="UML">UML</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div className="mb-4">
                        <label htmlFor="description" className="block mb-2 text-sm font-semibold text-gray-700">Description</label>
                        <textarea name="description" value={formData.description} onChange={handleChange} rows="4" className="w-full p-2 border border-gray-300 rounded-md" placeholder="Enter description here..."></textarea>
                    </div>
                    <div {...getRootProps()} className="flex justify-center items-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer">
                        <input {...getInputProps()} />
                        <p className="text-gray-600">Drag 'n' drop some files here, or click to select files</p>
                        <FaImage className="ml-2" />
                    </div>
                    {imagePreview && (
                        <div className="mt-4 flex justify-center">
                            <img src={imagePreview} alt="Preview" className="max-h-40" />
                        </div>
                    )}
                    {/* Rest of the form */}

                                         <div className="mb-4">
                        <label htmlFor="price" className="block mb-2 text-sm font-semibold text-gray-700">Price</label>
                        <input type="number" name="price" value={formData.price} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" placeholder="0.00" />
                    </div>

                    <div className="mb-4">
                        <label htmlFor="title" className="block mb-2 text-sm font-semibold text-gray-700">Title</label>
                        <input type="text" name="title" value={formData.title} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" placeholder="Enter title" />
                    </div>

                    <div className="mb-4">
                        <label htmlFor="size" className="block mb-2 text-sm font-semibold text-gray-700">Size</label>
                        <select name="size" value={formData.size} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md">
                            <option value="">Select Size</option>
                            <option value="S">S</option>
                            <option value="M">M</option>
                            <option value="L">L</option>
                            <option value="XL">XL</option>
                        </select>
                    </div>

                    <div className="mb-4">
                        <label htmlFor="rating" className="block mb-2 text-sm font-semibold text-gray-700">Rating</label>
                        <input type="number" name="rating" value={formData.rating} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" min="0" max="5" placeholder="Rating (0-5)" />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="count" className="block mb-2 text-sm font-semibold text-gray-700">Review Count</label>
                        <input type="number" name="count" value={formData.count} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" min="0" placeholder="Number of Reviews" />
                    </div>
                    <button type="submit" className="w-full p-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-300">Submit</button>
                </form>
            </div>
        </>
    );
};

export default ProductForm;


