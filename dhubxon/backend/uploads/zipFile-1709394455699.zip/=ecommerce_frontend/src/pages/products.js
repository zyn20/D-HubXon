import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { FaImage } from 'react-icons/fa';

const ProductForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        category: '',
        description: '',
        image: '',
        price: '',
        rating: 0, // Updated to be a single value
        count: 0, // New field for count
        title: '',
        size: '',
    });

    const [imageFile, setImageFile] = useState(null);

    const onImageDrop = useCallback((acceptedFiles) => {
        const file = acceptedFiles[0];
        if (file && (file.type === 'image/png' || file.type === 'image/jpeg')) {
            setImageFile(file);
            const fileUrl = URL.createObjectURL(file);
            setFormData({ ...formData, image: fileUrl });
        } else {
            alert('Only PNG or JPG files are accepted.');
        }
    }, [formData]);

    const { getRootProps, getInputProps } = useDropzone({
        onDrop: onImageDrop,
        accept: 'image/png, image/jpeg',
        multiple: false
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        // For rating and count, ensure that the input is converted to a number
        if (name === 'rating' || name === 'count') {
            setFormData({ ...formData, [name]: Number(value) });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
    
        // Check for required fields
        if (!formData.category || !formData.description || !formData.image || !formData.price || !formData.title || !formData.size || formData.rating === 0 || formData.count === 0) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'All fields must be filled, including rating and count!',
            });
            return;
        }
    
        const uploadFormData = new FormData();
        Object.keys(formData).forEach(key => {
            if (key === 'image' && imageFile) {
                uploadFormData.append(key, imageFile);
            } else if (key !== 'rating' && key !== 'count') {
                // Append everything except rating and count directly
                uploadFormData.append(key, formData[key]);
            }
        });
    
        // Append rating as a nested object requires handling it separately
        // Since you cannot directly append nested objects to FormData, you need to
        // ensure your backend can parse these values correctly
        uploadFormData.append('rating[rate]', formData.rating.toString());
        uploadFormData.append('rating[count]', formData.count.toString());
    
        try {
            const response = await fetch('http://127.0.0.1:5000/freelancer/courses', {
                method: 'POST',
                body: uploadFormData,
                // You do not set headers here because the browser will automatically set the
                // Content-Type to multipart/form-data with the correct boundary.
            });
    
            if (response.ok) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Your product has been submitted!',
                }).then(() => {
                    navigate('/freelancer/');
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to add product. Please try again.',
                });
            }
        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An error occurred. Please try again.',
            });
        }
    };
    

    return (
        <>

        <nav class="bg-white shadow dark:bg-gray-800">
        <div class="container flex items-center justify-center p-6 mx-auto text-gray-600 capitalize dark:text-gray-300">
            <a href="#" class="text-gray-800 dark:text-gray-200 border-b-2 border-blue-500 mx-1.5 sm:mx-6">Products</a>    
        </div>
    </nav>  

            <div className="max-w-md mx-auto mt-10 bg-white p-8 border border-gray-300 rounded-lg shadow-lg">
                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Form fields similar to previous component */}
                    {/* Additional fields for rating and count */}
                    <div className="mb-4">
                        <label htmlFor="category" className="block mb-2 text-sm font-semibold text-gray-700">Category</label>
                        <select name="category" value={formData.category} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md">
                            <option value="">Select a category</option>
                            <option value="Graphics Design">Graphics Design</option>
                            <option value="Web Development">Web Development</option>
                            <option value="Digital Marketing">Digital Marketing</option>
                            <option value="AI">AI</option>
                            <option value="Writing">Writing</option>
                            <option value="UML">UML</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div className="mb-4">
                        <label htmlFor="description" className="block mb-2 text-sm font-semibold text-gray-700">Description</label>
                        <textarea name="description" value={formData.description} onChange={handleChange} rows="4" className="w-full p-2 border border-gray-300 rounded-md" placeholder="Enter description here..."></textarea>
                    </div>

                    <div className="mb-4">
                        <label className="block mb-2 text-sm font-semibold text-gray-700">Product Image</label>
                        <div {...getRootProps()} className="flex justify-center items-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                            <input {...getInputProps()} />
                            <p className="text-gray-600">Drag 'n' drop some files here, or click to select files</p>
                            <FaImage className="ml-2" />
                        </div>
                        {formData.image && <img src={formData.image} alt="Preview" className="mt-4 mx-auto max-h-40" />}
                    </div>

                    <div className="mb-4">
                        <label htmlFor="price" className="block mb-2 text-sm font-semibold text-gray-700">Price</label>
                        <input type="number" name="price" value={formData.price} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" placeholder="0.00" />
                    </div>

                    <div className="mb-4">
                        <label htmlFor="title" className="block mb-2 text-sm font-semibold text-gray-700">Title</label>
                        <input type="text" name="title" value={formData.title} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" placeholder="Enter title" />
                    </div>

                    <div className="mb-4">
                        <label htmlFor="size" className="block mb-2 text-sm font-semibold text-gray-700">Size</label>
                        <select name="size" value={formData.size} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md">
                            <option value="">Select Size</option>
                            <option value="S">S</option>
                            <option value="M">M</option>
                            <option value="L">L</option>
                            <option value="XL">XL</option>
                        </select>
                    </div>
                  


                    <div className="mb-4">
                        <label htmlFor="rating" className="block mb-2 text-sm font-semibold text-gray-700">Rating</label>
                        <input type="number" name="rating" value={formData.rating} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" min="0" max="5" placeholder="Rating (0-5)" />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="count" className="block mb-2 text-sm font-semibold text-gray-700">Review Count</label>
                        <input type="number" name="count" value={formData.count} onChange={handleChange} className="w-full p-2 border border-gray-300 rounded-md" min="0" placeholder="Number of Reviews" />
                    </div>
                    <button type="submit" className="w-full p-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-300">Submit</button>
                    {/* Size select field included as before */}
                    {/* Submit button as before */}
                </form>
            </div>
        </>
    );
};

export default ProductForm;
