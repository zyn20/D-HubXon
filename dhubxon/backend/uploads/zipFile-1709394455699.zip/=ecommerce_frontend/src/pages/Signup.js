import Header from "../components_authentication/Header";
import Signup from "../components_authentication/Signup";

export default function SignupPage(){
    return(
    
        
      <div className="bg-white h-screen flex flex-col justify-center items-center">
      <div className="border rounded-lg border-black p-8">
        <>
          <Header
            heading="Signup to create an account"
            paragraph="Already have an account? "
            linkName="Login"
            linkUrl="/"
          />
          <Signup />
        </>
      
    </div>
    </div>
    )
}
