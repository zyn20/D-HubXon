import Header from "../components_authentication/Header"
import Login from "../components_authentication/Login"

export default function LoginPage(){
    return(
        <div className="bg-white h-screen flex flex-col justify-center items-center">
        <div className="border border-black rounded-lg p-16 ">
        <>
             <Header
                heading="Login to your account"
                paragraph="Don't have an account yet? "
                linkName="Signup"
                linkUrl="/signup"
                />
            <Login/>
        </>
        </div>
        </div>
       
    )
}