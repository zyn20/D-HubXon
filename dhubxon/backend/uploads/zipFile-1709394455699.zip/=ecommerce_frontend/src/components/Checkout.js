// import React, { useContext } from "react";
// import { Link } from "react-router-dom";
// import { FiTrash2 } from "react-icons/fi";
// import CartItem from "../components/CartItem";
// import { CartContext } from "../contexts/CartContext";
// import Header from "./Header";

// const Checkout = () => {
//   const { cart, clearCart, total } = useContext(CartContext);

//   return (
//     <>
//     <div className="">
//     <Header/>
//     </div>
//     <div className="container mx-auto py-20 ">
//       <h1 className="text-3xl font-semibold mb-4">Checkout</h1>
//       <div className="mb-4">
//         {cart.length > 0 ? (
//           cart.map((item) => <CartItem item={item} key={item.id} />)
//         ) : (
//           <p>Your cart is empty.</p>
//         )}
//       </div>
//       <div className="flex justify-between items-center">
//         <div>
//           <button onClick={clearCart} className="flex items-center gap-2 bg-red-500 text-white p-2 rounded hover:bg-red-600 transition duration-150 ease-in-out">
//             <FiTrash2 className="text-xl" />
//             Clear Cart
//           </button>
//         </div>
//         <div className="font-semibold text-xl">
//           Subtotal: ${parseFloat(total).toFixed(2)}
//         </div>
//       </div>
//       <div className="mt-6">
//         <Link to="/payment" className="bg-primary flex justify-center items-center text-white p-3 rounded w-full max-w-sm mx-auto font-medium hover:bg-primary-dark transition duration-150 ease-in-out">
//           Proceed to Payment
//         </Link>
//       </div>
//     </div>
//     </>
//   );
// };

// export default Checkout;
import React, { useContext, useState } from "react";
import { Link } from "react-router-dom";
import { FiTrash2 } from "react-icons/fi";
import CartItem from "../components/CartItem";
import { CartContext } from "../contexts/CartContext";
import Header from "./Header";
import Modal from "./Modal"; // Adjust the path as needed

const Checkout = () => {
  const { cart, clearCart, total } = useContext(CartContext);
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <Header />
      <div className="container mx-auto py-20 ">
        {/* Your existing code */}
        <h1 className="text-3xl font-semibold mb-4">Checkout</h1>
      <div className="mb-4">
        {cart.length > 0 ? (
          cart.map((item) => <CartItem item={item} key={item.id} />)
        ) : (
          <p>Your cart is empty.</p>
        )}
      </div>
      <div className="flex justify-between items-center">
        <div>
          <button onClick={clearCart} className="flex items-center gap-2 bg-red-500 text-white p-2 rounded hover:bg-red-600 transition duration-150 ease-in-out">
            <FiTrash2 className="text-xl" />
            Clear Cart
          </button>
        </div>
        <div className="font-semibold text-xl">
          Subtotal: ${parseFloat(total).toFixed(2)}
        </div>
      </div>
        <div className="mt-6">
          <button 
            onClick={() => setIsModalOpen(true)} 
            className="bg-primary flex justify-center items-center text-white p-3 rounded w-full max-w-sm mx-auto font-medium hover:bg-primary-dark transition duration-150 ease-in-out"
          >
            Proceed to Payment
          </button>
        </div>
      </div>
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <form className="flex flex-col space-y-4">
          <h2 className="text-lg font-semibold">Payment Information</h2>
          <input type="text" placeholder="Name" className="border p-2"/>
          <input type="text" placeholder="Address" className="border p-2"/>
          <input type="text" placeholder="Credit Card Number" className="border p-2"/>
          <input type="text" placeholder="Email Address" className="border p-2"/>
          <div className="font-semibold text-xl">
            Total: ${parseFloat(total).toFixed(2)}
          </div>
          <button 
            type="submit" 
            className="bg-black text-white p-2 rounded hover:bg-green-600 transition duration-150 ease-in-out"
          >
            Submit Payment
          </button>
        </form>
      </Modal>
    </>
  );
};

export default Checkout;
