import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Complete_home from "./complete_home";
import Complete_products from "./complete_products";
import Sidebar from "./components/Checkout";
import Admin from "./components/admin";
import Signup from "./pages/Signup";
import LoginPage from "./pages/Login";
import Courses from "./pages/newadmin";
import ProductForm from "./pages/products";
import ProductForm1 from "./pages/oneproduct";
const App = () => {
  return (
    
      <Router>
     
        <Routes>
          <Route path="/" element={<Complete_home/>}></Route>
          <Route path="/softwareproduct/:id" element={<Complete_products/>
          


          }></Route>
          <Route path="/checkout" element={<Sidebar/>
          

          
          }></Route>

          <Route path="/admin" element={<Admin/>
          

          
        }></Route>
        
        <Route path="/admindash" element={<Courses/>
          

          
      }></Route>
        <Route path="/login" element={<LoginPage/>}></Route>
        <Route path="/update-course/:id" element={<ProductForm1/>}></Route>
        
        <Route path="/Products" element={<ProductForm/>}></Route> 
                <Route path="/signup" element={<Signup/>} ></Route>

        </Routes>
        
        
      </Router>
    
  );
};

export default App;
