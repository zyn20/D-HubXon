const express = require("express");
const router = express.Router();
const courseController = require("../controllers/productcontroller");

const path = require('path');
const multer = require('multer');

// Set up storage directory
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); // the folder where files will be saved
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

router.post('/courses', upload.single('image'), courseController.addCourse);

router.get("/products", courseController.getAllCourses);

// Update course route with multer for handling file uploads
router.put('/courses/:id', upload.single('image'), courseController.updateCourse);

router.get('/courses/:id', courseController.getCourseById);

// Delete course route
router.delete('/courses/:id', courseController.deleteCourse);

router.get("*", function (req, res) {
  res.status(404).send("404 error: page not found");
});

module.exports = router;
