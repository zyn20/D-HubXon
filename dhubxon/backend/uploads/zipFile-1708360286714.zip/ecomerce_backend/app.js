const express = require('express');
const app = express();
const path=require('path')
const port = process.env.PORT || 5000;
const connectDB = require('./db/db');
const routesp=require("./routes/productroutes")
const bodyParser = require("body-parser");
const cors = require('cors');
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/freelancer', routesp);
// Serve static files from the 'uploads' directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const start = async () => {
  try {
    await connectDB('mongodb://ahmad:ahmad@ac-axftauw-shard-00-00.8o8iquo.mongodb.net:27017,ac-axftauw-shard-00-01.8o8iquo.mongodb.net:27017,ac-axftauw-shard-00-02.8o8iquo.mongodb.net:27017/mydb?ssl=true&replicaSet=atlas-9skgsb-shard-0&authSource=admin&retryWrites=true&w=majority');
    app.listen(port, () =>
      console.log(`Server is listening on port ${port}...`)
    );
  } catch (error) {
    console.log(error);
  }
};

start();

