const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  category: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  // MongoDB will automatically generate an ID, so you don't need to explicitly define it as you would in Sequelize.
  image: {
    type: String,
    required: true,
  },
  price: {
    type: Number, // Use Number for floats in Mongoose
    required: true,
  },
  rating: { 
    rate: {
      type: Number,
      default: 0.0,
    },
    count: {
      type: Number,
      default: 0,
    },
  },
  title: {
    type: String,
    required: true,
  },
  // Adding the 'size' attribute as per your requirement
  size: {
    type: String,
    required: true,
    enum: ['S', 'M', 'L', 'XL'], // This ensures the value is one of these four options
  }
}, {
  timestamps: false, // Disable timestamps as per your Sequelize model
});

module.exports = mongoose.model('Course', courseSchema);
