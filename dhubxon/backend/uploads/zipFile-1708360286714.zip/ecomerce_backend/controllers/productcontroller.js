
// Import the Course model
const Course = require('../models/products');

// Controller to add a new course
const addCourse = async (req, res) => {
  try {
    // Destructuring to include the 'size' field from the request body
    const { category, description, price, title, size } = req.body;
    
    // Destructure rate and count from the rating field in the request body
    const { rate, count } = req.body.rating || { rate: 0.0, count: 0 }; // Provide default values

    // Handle the uploaded image file
    let imagePath = '';
    if (req.file) {
      // Construct the path relative to the 'uploads' folder
      imagePath = '/uploads/' + req.file.filename;
    }

    // Create a new course using the Mongoose model
    const newCourse = new Course({
      category,
      description,
      image: imagePath, // Use the image path from the uploaded file
      price,
      rating: {
        rate, // Set the rate from the request body
        count, // Set the count from the request body
      },
      title,
      size, // Add this line to include the 'size' attribute
    });

    // Save the new course to the database
    await newCourse.save();

    res.status(201).json(newCourse);
  } catch (error) {
    // Handle errors
    console.error('Error adding course:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
// Controller to get a single course by its ID
const getCourseById = async (req, res) => {
  try {
    const courseId = req.params.id; // Get the course ID from the request parameters

    // Find the course by its ID
    const course = await Course.findById(courseId);

    if (!course) {
      return res.status(404).json({ error: 'Course not found' });
    }

    // Respond with the found course
    res.status(200).json(course);
  } catch (error) {
    // Handle errors
    console.error('Error getting course:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};


const getAllCourses = async (req, res) => {
  try {
    // Retrieve all courses from the database using Mongoose
    const courses = await Course.find({});

    // Respond with the list of courses
    res.status(200).json(courses);
  } catch (error) {
    // Handle errors
    console.error('Error getting courses:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
const updateCourse = async (req, res) => {
  try {
    const courseId = req.params.id;
    let updates = req.body;

    // Handle file upload
    if (req.file) {
      const imagePath = '/uploads/' + req.file.filename; // Construct image path
      updates.image = imagePath; // Update image path in updates object
    }

    // If rating is sent as separate fields (rate and count), construct the rating object
    // This step depends on how you're sending the data from the client
    if (updates.rate !== undefined || updates.count !== undefined) {
      updates.rating = { rate: updates.rate, count: updates.count };
      delete updates.rate;
      delete updates.count;
    }

    const updatedCourse = await Course.findByIdAndUpdate(courseId, updates, { new: true });

    if (!updatedCourse) {
      return res.status(404).json({ error: 'Course not found' });
    }

    res.status(200).json(updatedCourse);
  } catch (error) {
    console.error('Error updating course:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Controller to delete a course
const deleteCourse = async (req, res) => {
  try {
    const courseId = req.params.id; // Get the course ID from the request parameters

    // Find the course by ID and delete it
    const deletedCourse = await Course.findByIdAndDelete(courseId);

    if (!deletedCourse) {
      return res.status(404).json({ error: 'Course not found' });
    }

    // Respond with a success message
    res.status(200).json({ message: 'Course successfully deleted' });
  } catch (error) {
    // Handle errors
    console.error('Error deleting course:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};





module.exports = {
  addCourse,
  getAllCourses,updateCourse,deleteCourse,getCourseById
};
