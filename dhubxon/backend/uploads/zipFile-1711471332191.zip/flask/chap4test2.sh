#!/bin/bash

# 4.1.1 - Ensure cron daemon is enabled and running


title="4.1.1 - Ensure cron daemon is enabled and running"

systemctl is-enabled crond.service &> /dev/null
if [[ $? -eq 0 ]]; then
    result="Passed"
     additional_output="Cron daemon is enabled and running"
else
    result="Failed"
     additional_output="Cron daemon is not enabled and running"
fi

# Check if a custom CSV name is provided
if [ -n "$1" ]; then
    # Use the custom name if provided
    csv_filename="$1.csv"
else
    # Otherwise, use the timestamp
    timestamp=$(date +"%Y-%m-%d_%H:%M:%S")
    csv_filename="$timestamp.csv"
fi


echo "$title,$additional_output,$result" >> "$csv_filename"
echo "$title"
echo "$additional_output"
echo "$result"
echo "$1"
echo "$csv_filename"




